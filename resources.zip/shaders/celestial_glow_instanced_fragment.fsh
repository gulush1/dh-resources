#version 410 core

#define MAX_INSTANCES 64

layout(std140) uniform Uniforms {
    mat4 uProjection;
    vec4 uRects[MAX_INSTANCES];
    vec4 uRadii[MAX_INSTANCES];
    vec4 uColors1[MAX_INSTANCES];
    vec4 uColors2[MAX_INSTANCES];
    vec4 uColors3[MAX_INSTANCES];
    vec4 uColors4[MAX_INSTANCES];
    vec4 uMeta[MAX_INSTANCES];
};

in vec2 FragCoord;
flat in int vInstanceId;

out vec4 fragColor;

float sdRoundRect(vec2 p, vec2 halfSize, float r) {
    vec2 d = abs(p) - (halfSize - vec2(r));
    return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0) - r;
}

void main() {
    int id = vInstanceId;
    vec2 outer = uRects[id].zw;
    vec4 radius = uRadii[id];
    float glowRadius = uMeta[id].x;
    float softness = uMeta[id].y;
    float intensity = uMeta[id].z;
    float phase = uMeta[id].w;

    vec2 outerHalf = outer * 0.5;
    vec2 p = FragCoord * outer - outerHalf;
    vec2 innerHalf = max(outerHalf - vec2(glowRadius), vec2(0.0));

    float r;
    if (p.x < 0.0) {
        r = (p.y < 0.0) ? radius.x : radius.w;
    } else {
        r = (p.y < 0.0) ? radius.y : radius.z;
    }
    r = clamp(r, 0.0, min(innerHalf.x, innerHalf.y));

    float dist = sdRoundRect(p, innerHalf, r);
    float edge = smoothstep(-max(softness, fwidth(dist)), 0.0, dist);
    float outside = max(dist, 0.0);
    float falloff = 1.0 - smoothstep(0.0, glowRadius, outside);
    float alpha = edge * falloff * intensity;
    if (alpha <= 0.001) discard;

    vec2 colorP = clamp(p, -innerHalf, innerHalf);
    vec2 normalized = colorP / max(innerHalf, vec2(1.0));
    vec2 axis = vec2(cos(phase), sin(phase));
    float t = dot(normalized, axis) * 0.5 + 0.5;
    t = smoothstep(0.0, 1.0, t);
    vec4 color = mix(uColors1[id], uColors2[id], t);

    fragColor = vec4(color.rgb, alpha * color.a);
}
