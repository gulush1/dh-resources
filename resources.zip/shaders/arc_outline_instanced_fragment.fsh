#version 410 core

#define MAX_INSTANCES 64

layout(std140) uniform Uniforms {
    mat4 uProjection;
    vec4 uRects[MAX_INSTANCES];
    vec4 uParams[MAX_INSTANCES];
    vec4 uMeta[MAX_INSTANCES];
    vec4 uFillColors[MAX_INSTANCES];
    vec4 uOutlineColors[MAX_INSTANCES];
};

in vec2 vUV;
in vec2 vSize;
flat in int vInstanceId;

out vec4 fragColor;

float sdArc(in vec2 p, in float sca, in float scb, in float ra, in float rb) {
    p.x = abs(p.x);
    return ((scb * p.x > sca * p.y) ? length(p - vec2(sca, scb) * ra) :
                                      abs(length(p) - ra)) - rb;
}

void main() {
    int id = vInstanceId;
    vec2 p = (vUV - 0.5) * vSize;

    float rotRad = radians(uParams[id].w);
    float degRad = radians(uParams[id].z) * 0.5;

    mat2 rotMat = mat2(cos(rotRad), -sin(rotRad), sin(rotRad), cos(rotRad));
    p = rotMat * p;

    float ra = uParams[id].x * 0.5 - uParams[id].y * 0.5;
    float rb = uParams[id].y * 0.5;
    float outlineThickness = uMeta[id].y;

    vec2 sc = vec2(sin(degRad), cos(degRad));

    float dist = sdArc(p, sc.x, sc.y, ra, rb);
    float edge = max(length(vec2(dFdx(dist), dFdy(dist))), 1e-6) * 1.5;

    float arcAlpha = clamp(0.5 - dist / edge, 0.0, 1.0);

    if (arcAlpha <= 0.0) discard;

    float innerDist = -dist - outlineThickness;
    float fillAlpha = clamp(0.5 - innerDist / edge, 0.0, 1.0);

    vec4 fill = uFillColors[id] * fillAlpha;
    vec4 outline = uOutlineColors[id] * (1.0 - fillAlpha);

    vec4 finalColor = fill + outline;
    fragColor = vec4(finalColor.rgb, finalColor.a * arcAlpha);
}
