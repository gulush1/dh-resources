#version 410 core

#define MAX_INSTANCES 64

layout(std140) uniform Uniforms {
    mat4 uProjection;
    vec4 uRects[MAX_INSTANCES];
    vec4 uRadii[MAX_INSTANCES];
    vec4 uMeta[MAX_INSTANCES];
    vec4 uColors[MAX_INSTANCES * 9];
};

out vec2 vUV;
out vec2 vSize;
flat out int vInstanceId;

void main() {
    vec2 vertices[4] = vec2[](
        vec2(0.0, 0.0),
        vec2(1.0, 0.0),
        vec2(1.0, 1.0),
        vec2(0.0, 1.0)
    );

    int id = gl_InstanceID;
    vec4 rect = uRects[id];
    float z = uMeta[id].x;

    vec2 vertex = vertices[gl_VertexID];

    vUV = vertex;
    vSize = rect.zw;
    vInstanceId = id;

    vec2 pos = rect.xy + vertex * rect.zw;
    gl_Position = uProjection * vec4(pos, z, 1.0);
}
