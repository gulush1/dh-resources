#version 410 core

layout(std140) uniform Uniforms {
    mat4 uProjection;
    vec4 uRect;
    vec4 uRadii;
    vec4 uFirstColor;
    vec4 uSecondColor;
    vec4 uMeta;
};

in vec2 vUV;
in vec2 vSize;

out vec4 fragColor;

float sdRoundedBox(vec2 p, vec2 b, vec4 r) {
    float radius;
    if (p.x < 0.0) {
        radius = (p.y < 0.0) ? r.x : r.w;
    } else {
        radius = (p.y < 0.0) ? r.y : r.z;
    }
    radius = clamp(radius, 0.0, min(b.x, b.y));
    vec2 q = abs(p) - (b - vec2(radius));
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - radius;
}

void main() {
    vec2 pixelPos = vUV * vSize;
    vec2 center = vSize * 0.5;
    vec2 p = pixelPos - center;

    float dist = sdRoundedBox(p, center, uRadii);
    float edge = max(fwidth(dist), 0.0001);
    float alphaMask = 1.0 - smoothstep(-edge, edge, dist);
    if (alphaMask <= 0.0) discard;

    vec2 normalized = p / max(center, vec2(1.0));
    vec2 axis = vec2(cos(uMeta.x), sin(uMeta.x));
    float t = dot(normalized, axis) * 0.5 + 0.5;
    t = smoothstep(0.0, 1.0, t);

    vec4 color = mix(uFirstColor, uSecondColor, t);
    fragColor = vec4(color.rgb, color.a * alphaMask);
}
