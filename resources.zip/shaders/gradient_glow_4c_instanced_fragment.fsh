#version 410 core

#define MAX_INSTANCES 64

layout(std140) uniform Uniforms {
    mat4 uProjection;
    vec4 uRects[MAX_INSTANCES];
    vec4 uRadii[MAX_INSTANCES];
    vec4 uColorsTl[MAX_INSTANCES];
    vec4 uColorsTr[MAX_INSTANCES];
    vec4 uColorsBl[MAX_INSTANCES];
    vec4 uColorsBr[MAX_INSTANCES];
    vec4 uGlowColors[MAX_INSTANCES];
    vec4 uMeta[MAX_INSTANCES];
};

in vec2 vUV;
in vec2 vSize;
flat in int vInstanceId;

out vec4 fragColor;

float rdist(vec2 pos, vec2 size, vec4 radius) {
    radius.xy = (pos.x > 0.0) ? radius.xy : radius.wz;
    radius.x  = (pos.y > 0.0) ? radius.x : radius.y;

    vec2 v = abs(pos) - size + radius.x;
    return min(max(v.x, v.y), 0.0) + length(max(v, 0.0)) - radius.x;
}

float ralpha(vec2 size, vec2 coord, vec4 radius, float smoothness) {
    vec2 center = size * 0.5;
    float dist = rdist(center - (coord * size), center - 1.0, radius);
    return 1.0 - smoothstep(1.0 - smoothness, 1.0, dist);
}

vec4 createGradient(vec2 coords, vec4 tl, vec4 tr, vec4 bl, vec4 br) {
    vec4 top = mix(tl, tr, coords.x);
    vec4 bottom = mix(bl, br, coords.x);
    return mix(top, bottom, coords.y);
}

void main() {
    int id = vInstanceId;
    vec4 radii = uRadii[id];
    float glowSize = uMeta[id].x;
    float smoothness = uMeta[id].y;

    float alpha = ralpha(vSize, vUV, radii, smoothness);

    vec4 gradColor = createGradient(vUV, uColorsTl[id], uColorsTr[id], uColorsBl[id], uColorsBr[id]);
    vec4 expandedRadii = radii + vec4(glowSize);

    vec2 expandFactor = (vSize + vec2(glowSize * 2.0)) / vSize;
    vec2 expandedCoord = (vUV - 0.5) / expandFactor + 0.5;

    float glowDist = rdist((expandedCoord - 0.5) * (vSize + vec2(glowSize * 2.0)), vSize * 0.5, expandedRadii);
    float glowAlpha = 1.0 - smoothstep(-glowSize, glowSize * 0.5, glowDist);
    glowAlpha *= uGlowColors[id].a * (1.0 - alpha);

    vec4 glow = vec4(uGlowColors[id].rgb, glowAlpha);
    vec4 mainColor = vec4(gradColor.rgb, gradColor.a * alpha);

    vec4 result = vec4(
        mix(glow.rgb, mainColor.rgb, alpha),
        max(glow.a, mainColor.a)
    );

    if (result.a < 0.01) discard;

    fragColor = result;
}
