#version 410 core

in vec4 v_color;
in vec2 v_localUV;
in float v_radius;

out vec4 fragColor;

void main() {
    float rateX = abs(dFdx(v_localUV.x));
    float rateY = abs(dFdy(v_localUV.y));
    float width  = rateX > 0.0 ? 1.0 / rateX : 1.0;
    float height = rateY > 0.0 ? 1.0 / rateY : 1.0;

    vec2 size = vec2(width, height);
    vec2 pixelPos = v_localUV * size;
    vec2 center = size * 0.5;
    float r = clamp(v_radius, 0.0, min(center.x, center.y));

    vec2 p = pixelPos - center;
    vec2 q = abs(p) - center + r;
    float dist = min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;

    float edge = max(length(vec2(dFdx(dist), dFdy(dist))), 1e-6) * 1.5;
    float alpha = clamp(0.5 - dist / edge, 0.0, 1.0);

    if (alpha <= 0.0) discard;

    fragColor = vec4(v_color.rgb, v_color.a * alpha);
}
