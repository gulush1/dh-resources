#version 150

layout(std140) uniform Uniforms {
    vec4 uTexelDir;
    vec4 uColor;
    vec4 uParams;
};

uniform sampler2D Sampler0;

in vec2 vUV;

out vec4 fragColor;

const vec2 OFFSETS[9] = vec2[9](
    vec2(-1.0, -1.0), vec2(0.0, -1.0), vec2(1.0, -1.0),
    vec2(-1.0, 0.0), vec2(0.0, 0.0), vec2(1.0, 0.0),
    vec2(-1.0, 1.0), vec2(0.0, 1.0), vec2(1.0, 1.0)
);

vec2 unpackSeed(vec4 p) {
    vec4 b = floor(p * 255.0 + 0.5);
    return vec2(b.x * 256.0 + b.y, b.z * 256.0 + b.w) / 65535.0;
}

void main() {
    vec4 best = vec4(0.0);
    float bestD2 = 3.402823e38;
    for (int i = 0; i < 9; i++) {
        vec4 p = texture(Sampler0, vUV + OFFSETS[i] * uTexelDir.xy);
        if (dot(p, vec4(1.0)) <= 0.0) {
            continue;
        }
        vec2 seedUv = unpackSeed(p);
        vec2 dpx = (vUV - seedUv) * uTexelDir.zw;
        float d2 = dot(dpx, dpx);
        if (d2 < bestD2) {
            bestD2 = d2;
            best = p;
        }
    }
    fragColor = best;
}
