#version 410 core

#define MAX_INSTANCES 64

layout(std140) uniform Uniforms {
    mat4 uProjection;
    vec4 uRects[MAX_INSTANCES];
    vec4 uRadii[MAX_INSTANCES];
    vec4 uMeta[MAX_INSTANCES];
    vec4 uColors[MAX_INSTANCES * 9];
};

in vec2 vUV;
in vec2 vSize;
flat in int vInstanceId;

out vec4 fragColor;

float sdRoundedBox(vec2 p, vec2 b, vec4 r) {
    r.xy = (p.x > 0.0) ? r.xy : r.zw;
    r.x  = (p.y > 0.0) ? r.x  : r.y;
    vec2 q = abs(p) - b + r.x;
    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r.x;
}

float dither(vec2 uv) {
    return (fract(sin(dot(uv.xy, vec2(12.9898, 78.233))) * 43758.5453123) - 0.5) * (1.0 / 255.0);
}

vec4 sampleColor(vec2 uv, int base) {
    float x = uv.x * 2.0;
    float y = uv.y * 2.0;

    int ix = clamp(int(floor(x)), 0, 1);
    int iy = clamp(int(floor(y)), 0, 1);

    float fx = fract(x);
    float fy = fract(y);

    vec4 c00 = uColors[base + iy * 3 + ix];
    vec4 c10 = uColors[base + iy * 3 + ix + 1];
    vec4 c01 = uColors[base + (iy + 1) * 3 + ix];
    vec4 c11 = uColors[base + (iy + 1) * 3 + ix + 1];

    vec4 top = mix(c00, c10, fx);
    vec4 bot = mix(c01, c11, fx);
    return mix(top, bot, fy);
}

void main() {
    int id = vInstanceId;
    vec2 pixelPos = vUV * vSize;
    vec2 center = vSize * 0.5;

    float dist = sdRoundedBox(pixelPos - center, center, uRadii[id]);
    float edge = max(length(vec2(dFdx(dist), dFdy(dist))), 1e-6) * 1.5;
    float alpha = clamp(0.5 - dist / edge, 0.0, 1.0);

    if (alpha <= 0.0) discard;

    vec4 color = sampleColor(vUV, id * 9);
    color.rgb += dither(pixelPos);

    fragColor = vec4(color.rgb, color.a * alpha);
}
