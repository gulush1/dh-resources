#version 150

layout(std140) uniform Uniforms {
    vec4 uTexelDir;
    vec4 uColor;
    vec4 uParams;
};

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

in vec2 vUV;

out vec4 fragColor;

vec2 unpackSeed(vec4 p) {
    vec4 b = floor(p * 255.0 + 0.5);
    return vec2(b.x * 256.0 + b.y, b.z * 256.0 + b.w) / 65535.0;
}

void main() {
    vec4 p = texture(Sampler0, vUV);
    if (dot(p, vec4(1.0)) <= 0.0) {
        fragColor = vec4(0.0);
        return;
    }
    vec2 seedUv = unpackSeed(p);
    float d = length((vUV - seedUv) * uTexelDir.zw);
    vec4 m = texture(Sampler1, seedUv);
    float scale = clamp(m.a, 0.05, 1.0);
    float reff = max(uParams.x * scale, uParams.y);
    float x = clamp(d / reff, 0.0, 1.0);
    float fall = (1.0 - x) * (1.0 - x);
    fragColor = vec4(m.rgb * fall, fall);
}
