#version 150

layout(std140) uniform Uniforms {
    vec4 uTexelDir;
    vec4 uColor;
    vec4 uParams;
};

uniform sampler2D Sampler0;

in vec2 vUV;

out vec4 fragColor;

vec4 packSeed(vec2 uv) {
    vec2 v = clamp(uv, 0.0, 1.0) * 65535.0;
    vec2 hi = floor(v / 256.0);
    vec2 lo = floor(v - hi * 256.0);
    return vec4(hi.x, lo.x, hi.y, lo.y) / 255.0;
}

void main() {
    ivec2 maxC = ivec2(uTexelDir.zw) - 1;
    ivec2 base = ivec2(gl_FragCoord.xy) * 2;
    ivec2 chosen = min(base, maxC);
    float a = texelFetch(Sampler0, chosen, 0).a;
    if (a <= 0.001) {
        chosen = min(base + ivec2(1, 0), maxC);
        a = texelFetch(Sampler0, chosen, 0).a;
    }
    if (a <= 0.001) {
        chosen = min(base + ivec2(0, 1), maxC);
        a = texelFetch(Sampler0, chosen, 0).a;
    }
    if (a <= 0.001) {
        chosen = min(base + ivec2(1, 1), maxC);
        a = texelFetch(Sampler0, chosen, 0).a;
    }
    if (a <= 0.001) {
        fragColor = vec4(0.0);
        return;
    }
    vec2 uv = (vec2(chosen) + 0.5) / uTexelDir.zw;
    fragColor = packSeed(uv);
}
