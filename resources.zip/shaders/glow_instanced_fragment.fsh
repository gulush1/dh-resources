#version 410 core

#define MAX_INSTANCES 64

layout(std140) uniform Uniforms {
    mat4 uProjection;
    vec4 uRects[MAX_INSTANCES];
    vec4 uRadii[MAX_INSTANCES];
    vec4 uMainColors[MAX_INSTANCES];
    vec4 uGlowColors[MAX_INSTANCES];
    vec4 uMeta[MAX_INSTANCES];
};

in vec2 vUV;
in vec2 vSize;
in float vGlowSize;
flat in int vInstanceId;

out vec4 fragColor;

float sdRoundedBox(vec2 p, vec2 b, vec4 r) {
    r.xy = (p.x > 0.0) ? r.xy : r.zw;
    r.x  = (p.y > 0.0) ? r.x  : r.y;
    vec2 q = abs(p) - b + r.x;
    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r.x;
}

void main() {
    int id = vInstanceId;
    vec4 rect = uRects[id];
    vec4 radii = uRadii[id];
    float glowSize = uMeta[id].x;
    float smoothness = uMeta[id].y;

    vec2 pixelPos = vUV * vSize;
    vec2 innerSize = rect.zw;
    vec2 innerCenter = vSize * 0.5;

    vec2 innerHalf = innerSize * 0.5;
    vec4 innerRadii = min(radii, vec4(min(innerHalf.x, innerHalf.y)));
    float innerDist = sdRoundedBox(pixelPos - innerCenter, innerHalf, innerRadii);
    float edge = max(fwidth(innerDist), 0.0001);
    float mainAlpha = 1.0 - smoothstep(-edge, edge, innerDist);

    vec2 expandedHalf = innerHalf + vec2(glowSize);
    vec4 expandedRadii = min(radii + vec4(glowSize), vec4(min(expandedHalf.x, expandedHalf.y)));
    float glowDist = sdRoundedBox(pixelPos - innerCenter, expandedHalf, expandedRadii);
    float glowAlpha = 1.0 - smoothstep(-glowSize * smoothness, 0.0, glowDist);
    glowAlpha *= uGlowColors[id].a * (1.0 - uMainColors[id].a * mainAlpha);

    vec4 glowContrib = vec4(uGlowColors[id].rgb, glowAlpha);
    vec4 mainContrib = vec4(uMainColors[id].rgb, uMainColors[id].a * mainAlpha);

    vec4 result = vec4(
        mix(glowContrib.rgb, mainContrib.rgb, mainAlpha),
        max(glowContrib.a, mainContrib.a)
    );

    if (result.a < 0.01) discard;

    fragColor = result;
}
