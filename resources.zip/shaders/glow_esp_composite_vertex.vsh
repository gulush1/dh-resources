#version 150

layout(std140) uniform Uniforms {
    vec4 uTexelDir;
    vec4 uColor;
    vec4 uParams;
};

out vec2 vUV;

void main() {
    float x = (gl_VertexID == 1) ? 3.0 : -1.0;
    float y = (gl_VertexID == 2) ? 3.0 : -1.0;
    vUV = vec2((x + 1.0) * 0.5, (y + 1.0) * 0.5);
    gl_Position = vec4(x, y, 0.0, 1.0);
}
