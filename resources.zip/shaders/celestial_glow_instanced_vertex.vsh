#version 410 core

#define MAX_INSTANCES 64

layout(std140) uniform Uniforms {
    mat4 uProjection;
    vec4 uRects[MAX_INSTANCES];
    vec4 uRadii[MAX_INSTANCES];
    vec4 uColors1[MAX_INSTANCES];
    vec4 uColors2[MAX_INSTANCES];
    vec4 uColors3[MAX_INSTANCES];
    vec4 uColors4[MAX_INSTANCES];
    vec4 uMeta[MAX_INSTANCES];
};

out vec2 FragCoord;
out vec4 FragColor;
flat out int vInstanceId;

void main() {
    vec2 vertices[4] = vec2[](
        vec2(0.0, 0.0),
        vec2(0.0, 1.0),
        vec2(1.0, 1.0),
        vec2(1.0, 0.0)
    );

    int id = gl_InstanceID;
    int vertexId = gl_VertexID % 4;
    vec4 rect = uRects[id];
    vec2 vertex = vertices[vertexId];

    FragCoord = vertex;
    vInstanceId = id;
    if (vertexId == 0) {
        FragColor = uColors1[id];
    } else if (vertexId == 1) {
        FragColor = uColors2[id];
    } else if (vertexId == 2) {
        FragColor = uColors3[id];
    } else {
        FragColor = uColors4[id];
    }

    vec2 pos = rect.xy + vertex * rect.zw;
    gl_Position = uProjection * vec4(pos, 0.0, 1.0);
}
