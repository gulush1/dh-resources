#version 410 core

in vec3 Position;
in vec4 Color;

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    float _pad0;
    mat4 TextureMatrix;
};

layout(std140) uniform Projection {
    mat4 ProjMat;
};

out vec4 v_color;
out vec2 v_localUV;
out float v_radius;

const vec2 CORNER_UV[4] = vec2[4](
    vec2(0.0, 0.0),
    vec2(0.0, 1.0),
    vec2(1.0, 1.0),
    vec2(1.0, 0.0)
);

void main() {
    v_localUV = CORNER_UV[gl_VertexID % 4];
    v_radius = Position.z;
    v_color = Color * ColorModulator;

    gl_Position = ProjMat * ModelViewMat * vec4(Position.xy, 0.0, 1.0);
}
