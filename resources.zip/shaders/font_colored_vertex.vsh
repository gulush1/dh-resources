#version 150

layout(std140) uniform FontData {
    mat4 uProjection;
    vec4 uParams;
    vec4 uZ_Padding;
};

layout(std140) uniform GlyphData {
    vec4 glyphs[768];
};

out vec2 vTexCoord;
out vec4 vColor;

void main() {
    int glyphIndex = gl_VertexID / 6;
    int vertexIndex = gl_VertexID % 6;

    vec2 vertices[4] = vec2[](
        vec2(0.0, 0.0),
        vec2(1.0, 0.0),
        vec2(1.0, 1.0),
        vec2(0.0, 1.0)
    );
    int indices[6] = int[](0, 1, 2, 2, 3, 0);
    vec2 vertex = vertices[indices[vertexIndex]];

    vec4 rect    = glyphs[glyphIndex * 3];
    vec4 texRect = glyphs[glyphIndex * 3 + 1];
    vec4 color   = glyphs[glyphIndex * 3 + 2];

    vec2 pos = rect.xy + vertex * rect.zw;
    gl_Position = uProjection * vec4(pos, uZ_Padding.x, 1.0);

    vTexCoord = texRect.xy + vertex * texRect.zw;
    vColor    = color;
}
