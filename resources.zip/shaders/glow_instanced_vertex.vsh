#version 410 core

#define MAX_INSTANCES 64

layout(std140) uniform Uniforms {
    mat4 uProjection;
    vec4 uRects[MAX_INSTANCES];
    vec4 uRadii[MAX_INSTANCES];
    vec4 uMainColors[MAX_INSTANCES];
    vec4 uGlowColors[MAX_INSTANCES];
    vec4 uMeta[MAX_INSTANCES];
};

out vec2 vUV;
out vec2 vSize;
out float vGlowSize;
flat out int vInstanceId;

void main() {
    vec2 vertices[4] = vec2[](
        vec2(0.0, 0.0),
        vec2(1.0, 0.0),
        vec2(1.0, 1.0),
        vec2(0.0, 1.0)
    );

    int id = gl_InstanceID;
    vec4 rect = uRects[id];
    float glowSize = uMeta[id].x;
    float z = uMeta[id].z;

    vec2 vertex = vertices[gl_VertexID];

    vec2 expandedSize = rect.zw + vec2(glowSize * 2.0);
    vec2 pos = rect.xy - vec2(glowSize) + vertex * expandedSize;

    vUV = vertex;
    vSize = expandedSize;
    vGlowSize = glowSize;
    vInstanceId = id;

    gl_Position = uProjection * vec4(pos, z, 1.0);
}
