#version 150

layout(std140) uniform FontData {
    mat4 uProjection;
    vec4 uParams;
    vec4 uZ_Padding;
};

in vec2 vTexCoord;
in vec4 vColor;

out vec4 fragColor;

uniform sampler2D Sampler0;

float coverage(vec2 uv) {
    return texture(Sampler0, uv).r;
}

void main() {
    float alpha;
    if (uParams.z > 0.5) {
        vec2 dx = dFdx(vTexCoord) * 0.25;
        vec2 dy = dFdy(vTexCoord) * 0.25;
        alpha = (coverage(vTexCoord + dx + dy)
               + coverage(vTexCoord - dx + dy)
               + coverage(vTexCoord + dx - dy)
               + coverage(vTexCoord - dx - dy)) * 0.25;
    } else {
        alpha = coverage(vTexCoord);
    }

    float sharpen = uParams.x;
    if (sharpen > 0.0) {
        float contrast = mix(1.0, 2.5, sharpen);
        alpha = clamp((alpha - 0.5) * contrast + 0.5, 0.0, 1.0);
    }

    if (alpha < 0.01) discard;

    fragColor = vec4(vColor.rgb, vColor.a * alpha);
}
