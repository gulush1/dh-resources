#version 150

layout(std140) uniform Uniforms {
    vec4 uTexelDir;
    vec4 uColor;
    vec4 uParams;
};

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

in vec2 vUV;

out vec4 fragColor;

void main() {
    float maskA = texture(Sampler1, vUV).a;
    if (maskA > 0.0) {
        discard;
    }

    vec4 g = texture(Sampler0, vUV);
    if (g.a <= 0.0) {
        discard;
    }

    vec3 col = g.rgb / max(g.a, 0.0001);
    float alpha = clamp(g.a * uParams.x, 0.0, 1.0);
    fragColor = vec4(col, alpha);
}
