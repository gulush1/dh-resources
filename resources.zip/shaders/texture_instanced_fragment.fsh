#version 410 core

#define MAX_INSTANCES 64

layout(std140) uniform Uniforms {
    mat4 uProjection;
    vec4 uRects[MAX_INSTANCES];
    vec4 uMeta[MAX_INSTANCES];
    vec4 uColors[MAX_INSTANCES];
};

in vec2 vUV;
in vec2 vSize;
flat in int vInstanceId;

out vec4 fragColor;

uniform sampler2D Sampler0;

float sdRoundedRect(vec2 p, vec2 b, float r) {
    vec2 q = abs(p - b) - b + r;
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
}

void main() {
    int id = vInstanceId;
    float radius = uMeta[id].y;

    vec2 pixelPos = vUV * vSize;
    float dist = sdRoundedRect(pixelPos, vSize * 0.5, min(radius, min(vSize.x, vSize.y) * 0.5));
    float edge = fwidth(dist);
    float alpha = 1.0 - smoothstep(-edge, edge, dist);

    if (alpha <= 0.0) discard;

    vec4 tint = uColors[id];
    vec4 texColor = texture(Sampler0, vUV);
    fragColor = texColor * tint;
    fragColor.a *= alpha;
}
